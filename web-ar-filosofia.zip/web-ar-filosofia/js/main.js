/**
 * Alegoría de la Caverna – Experiencia WebAR educativa
 * Three.js + WebXR Device API (hit-test) + fallback 3D
 * Sin marcadores, sin QR, sin API keys, 100% gratuito
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

// ============================================================
// 1. CONFIGURACIÓN PEDAGÓGICA (fácil de adaptar a otros temas)
// ============================================================
const SCENE_CONFIG = {
  title: "Alegoría de la Caverna",
  author: "Platón",

  // Información que aparece al tocar cada objeto
  objectsInfo: {
    prisioneros: {
      title: "Los prisioneros",
      text: "Representan a la mayoría de las personas que solo conocen las apariencias (las sombras). Están encadenados y no pueden girar la cabeza. Para Platón, la educación es el proceso de liberarse de estas cadenas."
    },
    fuego: {
      title: "El fuego",
      text: "Es la fuente de luz artificial dentro de la caverna. Proyecta las sombras en la pared. Simboliza el conocimiento limitado y engañoso que recibimos a través de los sentidos y de las opiniones de los demás."
    },
    sombras: {
      title: "Las sombras",
      text: "Son las apariencias que los prisioneros toman por realidad. Para Platón, el mundo sensible es solo una copia imperfecta del mundo de las Ideas (Formas). Las sombras son el nivel más bajo de conocimiento: la eikasia (imaginación)."
    },
    estatua: {
      title: "Los objetos que proyectan sombras",
      text: "Figuras y estatuas que personas llevan detrás del muro. Representan las cosas del mundo físico. Aunque son más reales que las sombras, todavía no son las Ideas puras."
    },
    salida: {
      title: "La salida hacia la luz",
      text: "El camino de la educación y la filosofía. El prisionero liberado asciende hacia el sol (la Idea del Bien). Este ascenso es doloroso al principio, pero permite contemplar la verdadera realidad."
    },
    sol: {
      title: "El Sol – La Idea del Bien",
      text: "En la alegoría, el Sol representa la Idea del Bien, la realidad suprema. Ilumina y hace posible conocer todas las demás Ideas. Es el objetivo final de la educación filosófica."
    }
  }
};

// ============================================================
// 2. ESTADO GLOBAL
// ============================================================
let renderer, scene, camera;
let controller, reticle;          // WebXR
let hitTestSource = null;
let hitTestSourceRequested = false;
let placed = false;               // ¿Ya se colocó la escena?
let arSession = null;
let orbitControls = null;
let isFallbackMode = false;
let interactiveObjects = [];      // objetos que se pueden tocar
let raycaster = new THREE.Raycaster();
let pointer = new THREE.Vector2();

// Grupos de la escena
let caveGroup = null;

// ============================================================
// 3. INICIALIZACIÓN
// ============================================================
async function init() {
  const canvas = document.getElementById('c');

  // Renderer
  renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: true,
    powerPreference: 'high-performance'
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.xr.enabled = true;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  // Escena
  scene = new THREE.Scene();

  // Cámara
  camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.01, 40);
  camera.position.set(0, 1.6, 3);

  // Luces base (se ajustan según el modo)
  const ambient = new THREE.AmbientLight(0xffffff, 0.45);
  scene.add(ambient);

  const dirLight = new THREE.DirectionalLight(0xfff0dd, 1.1);
  dirLight.position.set(3, 6, 2);
  dirLight.castShadow = true;
  dirLight.shadow.mapSize.set(1024, 1024);
  scene.add(dirLight);

  // Retículo (indicador de colocación)
  reticle = createReticle();
  reticle.visible = false;
  scene.add(reticle);

  // Crear la geometría de la caverna (pero no colocarla todavía)
  caveGroup = createCaveScene();
  caveGroup.visible = false;
  scene.add(caveGroup);

  // Eventos de UI
  setupUI();

  // Verificar compatibilidad
  await checkCompatibility();

  // Resize
  window.addEventListener('resize', onWindowResize);

  // Loop de render
  renderer.setAnimationLoop(render);
}

// ============================================================
// 4. COMPATIBILIDAD WebXR
// ============================================================
async function checkCompatibility() {
  const statusEl = document.getElementById('compat-status');
  const btnAR = document.getElementById('btn-start-ar');
  const btnFallback = document.getElementById('btn-fallback');
  const instructions = document.getElementById('instructions');

  // Necesitamos HTTPS (o localhost)
  const isSecure = window.isSecureContext;
  if (!isSecure) {
    statusEl.className = 'status error';
    statusEl.innerHTML = `
      <p><strong>Conexión no segura</strong></p>
      <p>La Realidad Aumentada requiere HTTPS. 
      Publicá el proyecto en GitHub Pages o usá un servidor local con HTTPS.</p>
    `;
    btnFallback.classList.remove('hidden');
    return;
  }

  // ¿Soporta WebXR?
  if (!navigator.xr) {
    statusEl.className = 'status warn';
    statusEl.innerHTML = `
      <p><strong>WebXR no disponible</strong></p>
      <p>Tu navegador no soporta WebXR. 
      Probá con Chrome o Edge en un dispositivo Android con ARCore.</p>
    `;
    btnFallback.classList.remove('hidden');
    instructions.classList.remove('hidden');
    return;
  }

  // ¿Soporta sesión immersive-ar?
  try {
    const supported = await navigator.xr.isSessionSupported('immersive-ar');
    if (supported) {
      statusEl.className = 'status ok';
      statusEl.innerHTML = `
        <p><strong>✓ Dispositivo compatible</strong></p>
        <p>Podés usar Realidad Aumentada. 
        Se recomienda un espacio bien iluminado y una superficie plana.</p>
      `;
      btnAR.disabled = false;
      btnAR.classList.remove('hidden');
      btnFallback.classList.remove('hidden');
      instructions.classList.remove('hidden');
    } else {
      statusEl.className = 'status warn';
      statusEl.innerHTML = `
        <p><strong>AR no soportado en este dispositivo</strong></p>
        <p>Tu navegador tiene WebXR, pero no admite sesiones de Realidad Aumentada 
        (necesita ARCore en Android o ARKit en iOS con navegador compatible).</p>
      `;
      btnFallback.classList.remove('hidden');
      instructions.classList.remove('hidden');
    }
  } catch (err) {
    statusEl.className = 'status error';
    statusEl.innerHTML = `<p>Error al comprobar compatibilidad: ${err.message}</p>`;
    btnFallback.classList.remove('hidden');
  }
}

// ============================================================
// 5. CREACIÓN DE LA ESCENA 3D (geometrías puras, sin modelos externos)
// ============================================================
function createCaveScene() {
  const group = new THREE.Group();
  group.name = 'caveScene';

  // --- Pared de la caverna (fondo) ---
  const wallGeo = new THREE.PlaneGeometry(4.2, 2.6);
  const wallMat = new THREE.MeshStandardMaterial({
    color: 0x3d2b1f,
    roughness: 0.9,
    metalness: 0.05,
    side: THREE.DoubleSide
  });
  const wall = new THREE.Mesh(wallGeo, wallMat);
  wall.position.set(0, 1.1, -1.8);
  wall.receiveShadow = true;
  group.add(wall);

  // --- Suelo de la caverna ---
  const floorGeo = new THREE.PlaneGeometry(4.5, 3.5);
  const floorMat = new THREE.MeshStandardMaterial({
    color: 0x2a2118,
    roughness: 0.95
  });
  const floor = new THREE.Mesh(floorGeo, floorMat);
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = 0;
  floor.receiveShadow = true;
  group.add(floor);

  // --- Muro bajo detrás de los prisioneros (donde pasan las estatuas) ---
  const lowWallGeo = new THREE.BoxGeometry(3.8, 0.55, 0.18);
  const lowWallMat = new THREE.MeshStandardMaterial({ color: 0x4a3728, roughness: 0.85 });
  const lowWall = new THREE.Mesh(lowWallGeo, lowWallMat);
  lowWall.position.set(0, 0.28, -0.55);
  lowWall.castShadow = true;
  lowWall.receiveShadow = true;
  group.add(lowWall);

  // --- Prisioneros (3 figuras sentadas) ---
  const prisoners = createPrisoners();
  prisoners.position.set(0, 0, 0.35);
  prisoners.name = 'prisioneros';
  group.add(prisoners);
  interactiveObjects.push(prisoners);

  // --- Fuego (izquierda) ---
  const fire = createFire();
  fire.position.set(-1.55, 0.05, -0.9);
  fire.name = 'fuego';
  group.add(fire);
  interactiveObjects.push(fire);

  // --- Sombras en la pared (planos oscuros proyectados) ---
  const shadows = createShadows();
  shadows.position.set(0, 1.0, -1.78);
  shadows.name = 'sombras';
  group.add(shadows);
  interactiveObjects.push(shadows);

  // --- Estatuas / objetos que proyectan sombras ---
  const statues = createStatues();
  statues.position.set(0, 0.55, -0.85);
  statues.name = 'estatua';
  group.add(statues);
  interactiveObjects.push(statues);

  // --- Camino de salida (derecha, subiendo) ---
  const exitPath = createExitPath();
  exitPath.position.set(1.7, 0, 0.2);
  exitPath.name = 'salida';
  group.add(exitPath);
  interactiveObjects.push(exitPath);

  // --- Sol (afuera, arriba a la derecha) ---
  const sun = createSun();
  sun.position.set(2.6, 2.4, 1.8);
  sun.name = 'sol';
  group.add(sun);
  interactiveObjects.push(sun);

  // Escala general para que sea cómoda en AR
  group.scale.setScalar(0.55);

  return group;
}

function createPrisoners() {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x6b5b4f, roughness: 0.8 });
  const headMat = new THREE.MeshStandardMaterial({ color: 0xc4a484, roughness: 0.7 });

  for (let i = -1; i <= 1; i++) {
    const prisoner = new THREE.Group();

    // Cuerpo (cilindro)
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 0.35, 10), bodyMat);
    body.position.y = 0.25;
    body.castShadow = true;
    prisoner.add(body);

    // Cabeza
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 10), headMat);
    head.position.y = 0.48;
    head.castShadow = true;
    prisoner.add(head);

    // Cadenas (líneas simples)
    const chainMat = new THREE.MeshStandardMaterial({ color: 0x555555, metalness: 0.7, roughness: 0.4 });
    const chain = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.5, 6), chainMat);
    chain.rotation.z = Math.PI / 2;
    chain.position.set(0.25, 0.3, 0);
    prisoner.add(chain);

    prisoner.position.x = i * 0.55;
    group.add(prisoner);
  }

  // Hacer el grupo "tocable" con un volumen invisible más grande
  const hitBox = new THREE.Mesh(
    new THREE.BoxGeometry(1.8, 0.7, 0.5),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitBox.position.y = 0.3;
  group.add(hitBox);

  return group;
}

function createFire() {
  const group = new THREE.Group();

  // Troncos
  const logMat = new THREE.MeshStandardMaterial({ color: 0x3e2723, roughness: 0.9 });
  for (let i = 0; i < 3; i++) {
    const log = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.35, 6), logMat);
    log.rotation.z = Math.PI / 2;
    log.rotation.y = (i - 1) * 0.6;
    log.position.y = 0.04;
    log.castShadow = true;
    group.add(log);
  }

  // Llama (conos apilados con colores cálidos)
  const flameColors = [0xff6b00, 0xff9500, 0xffcc00];
  flameColors.forEach((color, i) => {
    const flame = new THREE.Mesh(
      new THREE.ConeGeometry(0.12 - i * 0.03, 0.28 - i * 0.05, 8),
      new THREE.MeshStandardMaterial({
        color,
        emissive: color,
        emissiveIntensity: 0.8,
        transparent: true,
        opacity: 0.9
      })
    );
    flame.position.y = 0.25 + i * 0.08;
    group.add(flame);
  });

  // Luz puntual del fuego
  const fireLight = new THREE.PointLight(0xff6b00, 1.8, 4, 1.5);
  fireLight.position.y = 0.4;
  fireLight.castShadow = true;
  group.add(fireLight);

  // Hit box
  const hitBox = new THREE.Mesh(
    new THREE.SphereGeometry(0.35),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitBox.position.y = 0.3;
  group.add(hitBox);

  return group;
}

function createShadows() {
  const group = new THREE.Group();
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x111111,
    transparent: true,
    opacity: 0.55,
    side: THREE.DoubleSide
  });

  // Formas de sombra (siluetas simples)
  const shapes = [
    { w: 0.35, h: 0.7, x: -0.9 },
    { w: 0.45, h: 0.55, x: -0.2 },
    { w: 0.3, h: 0.65, x: 0.55 }
  ];

  shapes.forEach(s => {
    const shadow = new THREE.Mesh(new THREE.PlaneGeometry(s.w, s.h), shadowMat);
    shadow.position.set(s.x, 0, 0.01);
    group.add(shadow);
  });

  // Hit box grande
  const hitBox = new THREE.Mesh(
    new THREE.PlaneGeometry(2.5, 1.2),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  group.add(hitBox);

  return group;
}

function createStatues() {
  const group = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0x8d7b68, roughness: 0.7 });

  // Tres figuras simples que "pasan" detrás del muro
  const positions = [-0.7, 0, 0.7];
  positions.forEach((x, i) => {
    const statue = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.4, 0.12), mat);
    body.position.y = 0.2;
    body.castShadow = true;
    statue.add(body);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 6), mat);
    head.position.y = 0.48;
    head.castShadow = true;
    statue.add(head);

    // Alguna con forma de animal (cone)
    if (i === 1) {
      const animal = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.3, 6), mat);
      animal.rotation.x = Math.PI / 2;
      animal.position.set(0, 0.15, 0.15);
      statue.add(animal);
    }

    statue.position.x = x;
    group.add(statue);
  });

  const hitBox = new THREE.Mesh(
    new THREE.BoxGeometry(2.2, 0.6, 0.4),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitBox.position.y = 0.25;
  group.add(hitBox);

  return group;
}

function createExitPath() {
  const group = new THREE.Group();

  // Escalones / camino ascendente
  const stepMat = new THREE.MeshStandardMaterial({ color: 0x5c4033, roughness: 0.85 });
  for (let i = 0; i < 5; i++) {
    const step = new THREE.Mesh(
      new THREE.BoxGeometry(0.7, 0.08, 0.35),
      stepMat
    );
    step.position.set(0, 0.04 + i * 0.12, -i * 0.28);
    step.castShadow = true;
    step.receiveShadow = true;
    group.add(step);
  }

  // Flecha / indicador de salida
  const arrowMat = new THREE.MeshStandardMaterial({
    color: 0xfbbf24,
    emissive: 0xf59e0b,
    emissiveIntensity: 0.4
  });
  const arrow = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.3, 4), arrowMat);
  arrow.rotation.x = -Math.PI / 2;
  arrow.position.set(0, 0.7, -1.3);
  group.add(arrow);

  const hitBox = new THREE.Mesh(
    new THREE.BoxGeometry(0.9, 1.0, 1.8),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitBox.position.set(0, 0.4, -0.6);
  group.add(hitBox);

  return group;
}

function createSun() {
  const group = new THREE.Group();

  // Esfera brillante
  const sunMat = new THREE.MeshStandardMaterial({
    color: 0xffe566,
    emissive: 0xffcc00,
    emissiveIntensity: 1.2
  });
  const sun = new THREE.Mesh(new THREE.SphereGeometry(0.28, 16, 12), sunMat);
  group.add(sun);

  // Halo
  const haloMat = new THREE.MeshBasicMaterial({
    color: 0xffe566,
    transparent: true,
    opacity: 0.25,
    side: THREE.DoubleSide
  });
  const halo = new THREE.Mesh(new THREE.CircleGeometry(0.55, 24), haloMat);
  group.add(halo);

  // Luz
  const sunLight = new THREE.PointLight(0xfff0c0, 2.2, 8, 1);
  group.add(sunLight);

  const hitBox = new THREE.Mesh(
    new THREE.SphereGeometry(0.5),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  group.add(hitBox);

  return group;
}

function createReticle() {
  const group = new THREE.Group();

  // Anillo exterior
  const ringGeo = new THREE.RingGeometry(0.12, 0.15, 32);
  const ringMat = new THREE.MeshBasicMaterial({
    color: 0x3b82f6,
    transparent: true,
    opacity: 0.9,
    side: THREE.DoubleSide
  });
  const ring = new THREE.Mesh(ringGeo, ringMat);
  ring.rotation.x = -Math.PI / 2;
  group.add(ring);

  // Punto central
  const dot = new THREE.Mesh(
    new THREE.CircleGeometry(0.025, 16),
    new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide })
  );
  dot.rotation.x = -Math.PI / 2;
  group.add(dot);

  return group;
}

// ============================================================
// 6. WEBXR – INICIO DE SESIÓN AR
// ============================================================
async function startAR() {
  try {
    arSession = await navigator.xr.requestSession('immersive-ar', {
      requiredFeatures: ['hit-test'],
      optionalFeatures: ['dom-overlay'],
      domOverlay: { root: document.body }
    });

    // Ocultar pantalla de inicio
    document.getElementById('start-screen').classList.add('hidden');
    document.getElementById('ar-ui').classList.remove('hidden');

    // Configurar referencia espacial
    await renderer.xr.setSession(arSession);

    // Cuando termina la sesión
    arSession.addEventListener('end', onARSessionEnd);

    // Evento de selección (toque)
    controller = renderer.xr.getController(0);
    controller.addEventListener('select', onSelect);
    scene.add(controller);

    placed = false;
    reticle.visible = false;
    caveGroup.visible = false;

  } catch (err) {
    console.error('Error al iniciar AR:', err);
    alert('No se pudo iniciar la sesión de Realidad Aumentada.\n\n' + err.message);
    showFallback();
  }
}

function onARSessionEnd() {
  hitTestSourceRequested = false;
  hitTestSource = null;
  placed = false;
  reticle.visible = false;
  caveGroup.visible = false;
  document.getElementById('ar-ui').classList.add('hidden');
  document.getElementById('start-screen').classList.remove('hidden');
  document.getElementById('info-panel').classList.remove('visible');
  arSession = null;
}

// Colocación al tocar
function onSelect() {
  if (!placed && reticle.visible) {
    // Colocar la escena en la posición del retículo
    caveGroup.position.setFromMatrixPosition(reticle.matrix);
    caveGroup.quaternion.setFromRotationMatrix(reticle.matrix);
    // Ajustar altura para que el piso coincida
    caveGroup.visible = true;
    placed = true;
    reticle.visible = false;
    document.getElementById('placement-hint').textContent =
      'Toca los objetos para conocer su significado filosófico';
  } else if (placed) {
    // Raycast desde el controlador / cámara para detectar toques en objetos
    handleInteraction();
  }
}

// ============================================================
// 7. FALLBACK 3D (OrbitControls)
// ============================================================
function showFallback() {
  isFallbackMode = true;
  document.getElementById('start-screen').classList.add('hidden');
  document.getElementById('fallback-ui').classList.remove('hidden');

  // Fondo oscuro para el modo 3D
  scene.background = new THREE.Color(0x0f172a);

  // Colocar la escena frente a la cámara
  caveGroup.position.set(0, 0, 0);
  caveGroup.visible = true;
  placed = true;

  // Controles de órbita
  orbitControls = new OrbitControls(camera, renderer.domElement);
  orbitControls.target.set(0, 0.6, 0);
  orbitControls.enableDamping = true;
  orbitControls.dampingFactor = 0.08;
  orbitControls.minDistance = 1.2;
  orbitControls.maxDistance = 8;
  orbitControls.maxPolarAngle = Math.PI * 0.85;

  camera.position.set(1.8, 1.5, 3.2);
  orbitControls.update();

  // Toques en pantalla para interacción
  renderer.domElement.addEventListener('pointerdown', onPointerDown);
}

function exitFallback() {
  isFallbackMode = false;
  if (orbitControls) {
    orbitControls.dispose();
    orbitControls = null;
  }
  scene.background = null;
  caveGroup.visible = false;
  placed = false;
  document.getElementById('fallback-ui').classList.add('hidden');
  document.getElementById('start-screen').classList.remove('hidden');
  document.getElementById('info-panel').classList.remove('visible');
  renderer.domElement.removeEventListener('pointerdown', onPointerDown);
}

// ============================================================
// 8. INTERACCIÓN (toque en objetos)
// ============================================================
function onPointerDown(event) {
  if (!placed) return;

  // Coordenadas normalizadas
  const rect = renderer.domElement.getBoundingClientRect();
  pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

  handleInteraction();
}

function handleInteraction() {
  // En AR usamos la dirección del controlador; en fallback el raycaster de la cámara
  if (isFallbackMode) {
    raycaster.setFromCamera(pointer, camera);
  } else if (controller) {
    // Dirección del rayo desde el controlador
    const tempMatrix = new THREE.Matrix4();
    tempMatrix.identity().extractRotation(controller.matrixWorld);
    raycaster.ray.origin.setFromMatrixPosition(controller.matrixWorld);
    raycaster.ray.direction.set(0, 0, -1).applyMatrix4(tempMatrix);
  } else {
    return;
  }

  const intersects = raycaster.intersectObjects(interactiveObjects, true);

  if (intersects.length > 0) {
    // Subir hasta encontrar el objeto con nombre conocido
    let obj = intersects[0].object;
    while (obj && !SCENE_CONFIG.objectsInfo[obj.name]) {
      obj = obj.parent;
    }
    if (obj && SCENE_CONFIG.objectsInfo[obj.name]) {
      showInfo(obj.name);
      // Pequeña animación de feedback
      pulseObject(obj);
    }
  }
}

function showInfo(key) {
  const info = SCENE_CONFIG.objectsInfo[key];
  if (!info) return;

  document.getElementById('info-title').textContent = info.title;
  document.getElementById('info-text').textContent = info.text;
  document.getElementById('info-panel').classList.add('visible');
}

function pulseObject(obj) {
  const originalScale = obj.scale.clone();
  obj.scale.multiplyScalar(1.12);
  setTimeout(() => {
    obj.scale.copy(originalScale);
  }, 180);
}

// ============================================================
// 9. UI Y EVENTOS
// ============================================================
function setupUI() {
  document.getElementById('btn-start-ar').addEventListener('click', startAR);
  document.getElementById('btn-fallback').addEventListener('click', showFallback);
  document.getElementById('btn-exit-ar').addEventListener('click', () => {
    if (arSession) arSession.end();
  });
  document.getElementById('btn-back-start').addEventListener('click', exitFallback);
  document.getElementById('btn-reset-view').addEventListener('click', () => {
    if (orbitControls) {
      camera.position.set(1.8, 1.5, 3.2);
      orbitControls.target.set(0, 0.6, 0);
      orbitControls.update();
    }
  });
  document.getElementById('btn-close-info').addEventListener('click', () => {
    document.getElementById('info-panel').classList.remove('visible');
  });
}

// ============================================================
// 10. RENDER LOOP + HIT-TEST
// ============================================================
function render(timestamp, frame) {
  if (orbitControls) orbitControls.update();

  // Animación sutil del fuego y el sol
  animateScene(timestamp);

  if (frame && arSession) {
    const referenceSpace = renderer.xr.getReferenceSpace();
    const session = renderer.xr.getSession();

    // Solicitar hit-test source una sola vez
    if (!hitTestSourceRequested) {
      session.requestReferenceSpace('viewer').then(refSpace => {
        session.requestHitTestSource({ space: refSpace }).then(source => {
          hitTestSource = source;
        });
      });
      hitTestSourceRequested = true;
    }

    // Actualizar retículo
    if (hitTestSource && !placed) {
      const hitTestResults = frame.getHitTestResults(hitTestSource);
      if (hitTestResults.length > 0) {
        const hit = hitTestResults[0];
        const pose = hit.getPose(referenceSpace);
        reticle.visible = true;
        reticle.matrix.fromArray(pose.transform.matrix);
      } else {
        reticle.visible = false;
      }
    }
  }

  renderer.render(scene, camera);
}

function animateScene(time) {
  if (!caveGroup || !caveGroup.visible) return;

  // Llama del fuego (escala sutil)
  const fire = caveGroup.getObjectByName('fuego');
  if (fire) {
    const t = time * 0.004;
    fire.children.forEach((child, i) => {
      if (child.geometry && child.geometry.type === 'ConeGeometry') {
        child.scale.y = 1 + Math.sin(t + i) * 0.12;
        child.scale.x = 1 + Math.cos(t * 1.3 + i) * 0.08;
      }
    });
  }

  // Rotación lenta del sol
  const sun = caveGroup.getObjectByName('sol');
  if (sun) {
    sun.rotation.y = time * 0.0003;
  }
}

function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

// ============================================================
// ARRANQUE
// ============================================================
init().catch(err => {
  console.error('Error de inicialización:', err);
  document.getElementById('compat-status').className = 'status error';
  document.getElementById('compat-status').innerHTML =
    `<p>Error al cargar la experiencia: ${err.message}</p>`;
});
